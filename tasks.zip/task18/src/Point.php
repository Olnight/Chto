<?php

namespace App;

class Point 
{
    public static $table = 'points';
}